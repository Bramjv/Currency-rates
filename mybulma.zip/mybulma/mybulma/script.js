var copyrightElement = document.getElementById("copyright");

var currentDate = new Date();

var currentYear = currentDate.getFullYear();

var copyrightSymbol = '\u00A9';

copyrightElement.textContent = copyrightSymbol+ " " + currentYear + " Michał Raszewski. Website content is from ";

var linkElement = document.getElementById("link");

linkElement.addEventListener("click", function() {
  var linkURL = linkElement.querySelector("a").getAttribute("href");
  window.open(linkURL, "_blank");
});

document.addEventListener('DOMContentLoaded', function() {
  const typewriterText = document.querySelector('.typewriter-text');
  const text = "Here you can easily see the exchange rates as well as see the price of PLN translated into other currencies.";
  let index = 0;

  function typeWriter() {
    if (index < text.length) {
      typewriterText.innerHTML += text.charAt(index);
      index++;
      setTimeout(typeWriter, 50);
    }
  }

  typeWriter();
});


document.addEventListener('DOMContentLoaded', function() {

    const timeRangeSelect = document.getElementById('timeRangeSelect');

    timeRangeSelect.addEventListener('change', async function () {
        const selectedRange = timeRangeSelect.value;
        await updateCharts(selectedRange);
    });
    
    async function fetchExchangeRate(currencyCode) {
      const response = await fetch(`http://api.nbp.pl/api/exchangerates/rates/A/${currencyCode}/today/?format=json`);
      const data = await response.json();
      return data.rates[0].mid;
    }
  
    async function convertCurrency() {
        const plnAmount = parseFloat(document.getElementById('pln').value);
        const currencyCode = document.getElementById('currencySelect').value;
      
        if (isNaN(plnAmount) || plnAmount < 0) {
          alert('Please enter a valid.');
          return;
        }
      
        try {
          const exchangeRate = await fetchExchangeRate(currencyCode);
          const convertedAmount = (plnAmount / exchangeRate).toFixed(2);
          document.getElementById('convertedAmount').innerHTML = `&nbsp;${convertedAmount}&nbsp;${currencyCode}&nbsp;`;
        } catch (error) {
          console.error('Error fetching exchange rate:', error);
          alert('Error fetching exchange rate. Please try again later.');
        }
      }
  
    async function fetchData(currencyCode, timeRange) {
      const response = await fetch(`http://api.nbp.pl/api/exchangerates/rates/A/${currencyCode}/last/${timeRange}/?format=json`);
      const data = await response.json();
      return data.rates;
    }
  
    async function prepareChartData(currencyCode, timeRange) {
      const rates = await fetchData(currencyCode, timeRange);
      const labels = rates.map(rate => rate.effectiveDate);
      const values = rates.map(rate => rate.mid);
      return { labels, values, currencyCode };
    }
  
    function drawChart(canvasId, labels, data, currencyCode, isSingleValue, selectedRange) {
      const ctx = document.getElementById(canvasId).getContext('2d');
        
      const percentageChange = calculatePercentageChange(data, selectedRange);
      updatePercentageChangeElement(currencyCode, percentageChange);
  
      if (Chart.getChart(ctx)) {
        Chart.getChart(ctx).destroy();
      }
  
      if (isSingleValue) {
        const centerX = ctx.canvas.width / 2;
        const centerY = ctx.canvas.height / 2;
  
        ctx.font = '2.5rem Arial';
        ctx.fillStyle = 'hsl(0, 0%, 7%)';
  
        const text = `${currencyCode}: ${data[data.length - 1]}`;
        const textWidth = ctx.measureText(text).width;
        const textHeight = parseInt(ctx.font);
  
        ctx.fillText(text, centerX - textWidth / 2, centerY + textHeight / 4);
      } else {
        const percentageChange = calculatePercentageChange(data);
        updatePercentageChangeElement(currencyCode, percentageChange);
  
        new Chart(ctx, {
          type: 'line',
          data: {
            labels: labels,
            datasets: [{
              label: `${currencyCode} exchange rate against PLN`,
              data: data,
              borderColor: 'rgb(0, 191, 255)',
              borderWidth: 1,
              fill: false
            }]
          },
          options: {
            scales: {
              x: {
                type: 'category',
              },
              y: {
                beginAtZero: false
              }
            },
            plugins: {
              tooltip: {
                callbacks: {
                  footer: (tooltipItems) => {
                    return [`Change: ${percentageChange.toFixed(2)}%`];
                  }
                }
              }
            }
          }
        });
      }
    }
  
    function calculatePercentageChange(data, selectedRange) {
      if (selectedRange === '1') {
        return 0;
      }
  
      const currentRate = data[data.length - 1];
      const previousRate = data[0];
  
      const percentageChange = ((currentRate - previousRate) / previousRate) * 100;
      return percentageChange;
    }
  
    function updatePercentageChangeElement(currencyCode, percentageChange) {
      const elementId = `${currencyCode.toLowerCase()}Change`;
      const element = document.getElementById(elementId);
  
      if (element) {
        const formattedPercentageChange = percentageChange.toFixed(2);
        element.textContent = `Change: ${formattedPercentageChange}%`;
  
        element.style.color = percentageChange >= 0 ? 'rgb(0,255,60)' : 'red';
      }
    }
  
    async function updateCharts(selectedRange) {
      const usdData = await prepareChartData('USD', selectedRange);
      const isSingleValue = selectedRange === '1';
      drawChart('usdChart', usdData.labels, usdData.values, 'USD', isSingleValue, selectedRange);
    
      const eurData = await prepareChartData('EUR', selectedRange);
      drawChart('eurChart', eurData.labels, eurData.values, 'EUR', isSingleValue, selectedRange);
    
      const chfData = await prepareChartData('CHF', selectedRange);
      drawChart('chfChart', chfData.labels, chfData.values, 'CHF', isSingleValue, selectedRange);
    }
  
    async function initializeCharts() {
        const defaultTimeRange = '7';
        const usdData = await prepareChartData('USD', defaultTimeRange);
        drawChart('usdChart', usdData.labels, usdData.values, 'USD', false);

        const eurData = await prepareChartData('EUR', defaultTimeRange);
        drawChart('eurChart', eurData.labels, eurData.values, 'EUR', false);

        const chfData = await prepareChartData('CHF', defaultTimeRange);
        drawChart('chfChart', chfData.labels, chfData.values, 'CHF', false);
    }

    initializeCharts();

    document.getElementById('checkButton').addEventListener('click', convertCurrency);
});